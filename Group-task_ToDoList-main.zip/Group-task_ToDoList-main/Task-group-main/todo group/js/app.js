/* =================== Selecting DOM Elements =================== */

const taskList = document.querySelector('.task-list');
const inputTitle = document.querySelector('#title-submit');
const inputText = document.querySelector('#text-submit');
const btn = document.querySelector('.add-btn');
const form = document.querySelector('.submit-form');
const closeBtn = document.querySelector('.fa-times-circle');
const searchInput = document.querySelector('#filter-input');
const popUp = document.querySelector('.submit-form-popup');
const mainContainer = document.querySelector('.main-container');


/* =================== Add Event Listeners =================== */

btn.addEventListener('click', showPopUp);
form.addEventListener('submit', addTask);
taskList.addEventListener('click', modifyTask);
closeBtn.addEventListener('click', closePopUp);
searchInput.addEventListener('keyup', filterNames);
document.addEventListener('DOMContentLoaded', loadSite);

/* =================== Calling functions =================== */

DatesAdd()



/* =================== Utillitis =================== */

/* ------------ Function for Local Storage ------------ */
function loadDataFromLocalStorage() {

    let data; // <-- Initializng the data structure //

    if (localStorage.getItem('tasks')) { // <-- Check to see if there is a key with some data //
        data = JSON.parse(localStorage.getItem('tasks')); // <-- Converting from string to javascript object //
    } else {
        data = []; // <-- Else make an empty array //
    }

    return data;
}


/* =================== Function Show Pop-up Box =================== */

function showPopUp(e) {

    popUp.style.display = 'flex'; // <-- Show it in the DOM //
    mainContainer.style.opacity = '.2'; // <-- Make some opacity in the background (to make it stand out) //
}


/* =================== Function Submit Form =================== */

function addTask(e) {
    e.preventDefault();

    /* ------------ Create an li if the inputs has values ------------ */
    if (inputTitle.value == '' && inputText.value == '') { // <-- Check if the inputs are empty //
        alert('Enter a text!');
    } else if (inputTitle.value == '') { // <-- Also check if the Title input are empty //
        alert('Enter a title!');
    } else {
        /* ------------ Save the inputs values to Local storage ------------ */
        const data = loadDataFromLocalStorage(); // <-- Get the localstorage function //

        const tasksObject = { // <-- Get the title and text value an put in an object //
            title: inputTitle.value,
            text: inputText.value
        };

        data.push(tasksObject); // <-- Add the inputs values into the data struture //

        localStorage.setItem('tasks', JSON.stringify(data)); // <-- Save data back to local storage //

        /* ------------ Create an li ------------ */
        const htmlCode = `
        <li class="task-item">
            <div class="task-item-content">
                <h3 class="task-title">${inputTitle.value.charAt(0).toUpperCase() + inputTitle.value.slice(1)}</h3> 
                <p class="task-text">${inputText.value.charAt(0).toUpperCase() + inputText.value.slice(1)}</p>
            </div>
            <div class="icons">
                <figure class="check-icon">
                    <i class="fas fa-check"></i>
                </figure>
                <figure class="cancel-icon">
                    <i class="fas fa-times"></i>
                </figure>
            </div>
        </li>`;

        taskList.innerHTML += htmlCode; // <-- Add li inside ul //

        /* ------------ Close the pop-up box when you save ------------ */
        popUp.style.display = 'none'; // <-- Hide it from the DOM //
        mainContainer.style.opacity = '1'; // <-- Get the background opacity back //

        /* ------------ Clear the pop-up input box ------------ */
        inputTitle.value = '';
        inputText.value = '';
    }
}


/* =================== Function Create Date Stamp =================== */

function DatesAdd() {
    /* ------------ Create the month ------------ */
    const d = new Date();
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    document.querySelector(".month").innerHTML = months[d.getMonth()];

    /* ------------ Create the year ------------ */
    const y = new Date();
    document.querySelector('.year').innerHTML = d.getFullYear();

    /* ------------ Create the date ------------ */
    const r = new Date();
    document.querySelector('.date').innerHTML = d.getDate();

    /* ------------ Create the day ------------ */
    const e = new Date();
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    document.querySelector('.day').innerHTML = days[e.getDay() - 1];
}


/* =================== Function Modify Icon Buttons =================== */

function modifyTask(e) {

    /* --- If you click the check icon, toggle the css class done, that make a line trough the text and low the opacity --- */
    if (e.target.classList.contains('fa-check')) {
        e.target.parentElement.parentElement.parentElement.classList.toggle('done'); //<-- Get the li and then toggle the class 'done' //
    }

    /* --- If you click the X icon, delete the li from the list --- */
    if (e.target.classList.contains('fa-times')) {
        const iDforLi = e.target.parentElement.parentElement.parentElement; //<-- Get the li and save it in a variabel //
        taskList.removeChild(iDforLi); /* Deleting the li from the list */


        /* --- Deleting from local storage --- */
        const data = loadDataFromLocalStorage(); //<-- initializng the data structure //

        const searchKey = e.target.parentElement.parentElement.previousElementSibling;

        for (let i = 0; i < data.length; i++) { //<-- Looping thought data to search for element //
            if (data[i] === searchKey) {

                data.splice(i, 1);//<-- Call splice method on the data structure //
            }
        }
        /* --- Save the changes to localstorage --- */
        localStorage.setItem('tasks', JSON.stringify(data));
    }

}

/* =================== Function Close Pop-up By Enter The X Button =================== */

function closePopUp(e) {

    popUp.style.display = 'none';
    mainContainer.style.opacity = '1'
}

/* =================== Function Input Filter Names =================== */

function filterNames() {
    const filterValue = searchInput.value.charAt(0).toUpperCase() + searchInput.value.slice(1); //<-- Get the input value and make the first letter to uppercase //

    const ul = document.querySelector('.task-list'); //<-- Get the ul //

    const li = ul.querySelectorAll('.task-item'); //<-- Select all li that exist in the ul //

    for (let i = 0; i < li.length; i++) { //<-- Looping thought the li's //
        let h3 = li[i].getElementsByTagName('h3')[0]; //<-- Target the current element start at 0 index//

        /* --- If it match --- */
        if (h3.innerHTML.indexOf(filterValue) > -1) {
            li[i].style.display = '';
        } else {
            li[i].style.display = 'none'; //<-- if it dosen't match, hide it //
        }
    }
}

/* =================== Function Reload Page =================== */

function loadSite() {
    const data = loadDataFromLocalStorage(); //<-- initializng the data structure //

    let htmlCode = '';

    for (let i = 0; i < data.length; i++) { // <-- Loop through the data and save it in the DOM //

        htmlCode += `
        <li class="task-item">
            <div class="task-item-content">
                <h3 class="task-title">${data[i].title.charAt(0).toUpperCase() + data[i].title.slice(1)}</h3>
                <p class="task-text">${data[i].text.charAt(0).toUpperCase() + data[i].text.slice(1)}</p>
            </div>
            <div class="icons">
                <figure class="check-icon">
                    <i class="fas fa-check"></i>
                </figure>
                <figure class="cancel-icon">
                    <i class="fas fa-times"></i>
                </figure>
            </div>
        </li>`;
    }

    taskList.innerHTML = htmlCode; // <-- Append the generated html code inside the ul //
}


